# SVM

* In this activity, apply a support vector machine classifier predict diabetes for the Pima Diabetes DataSet.

## Instructions

* Import a support vector machine linear classifier and fit the model to the data.

* Compute the classification report for this model using the test data.

- - -

© 2021 Trilogy Education Services, LLC, a 2U, Inc. brand. Confidential and Proprietary. All Rights Reserved.
