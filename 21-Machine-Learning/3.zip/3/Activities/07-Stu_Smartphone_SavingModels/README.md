# Smart Phone Activity Detector

## Instructions

* Follow the comments in the provided starter file to:

  * Encode necessary labels.

  * Build and train a deep learning model.

  * Save the model.

  * Load to model.

  * Use the loaded model to predict the activity of a smartphone user based one data point from the test set.
