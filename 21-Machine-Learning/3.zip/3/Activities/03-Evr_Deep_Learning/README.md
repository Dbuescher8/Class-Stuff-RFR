Everyone Do
